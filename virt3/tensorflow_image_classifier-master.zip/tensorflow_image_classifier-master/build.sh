docker build -t xblaster/tensor-guess .
