cp label_image.py /tf_files
cd /tf_files
python label_image.py /img/guess.jpg
