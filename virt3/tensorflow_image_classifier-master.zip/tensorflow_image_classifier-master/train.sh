docker run -v $1:/tf_files  xblaster/tensor-guess
